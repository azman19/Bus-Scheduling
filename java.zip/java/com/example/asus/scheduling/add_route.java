package com.example.asus.scheduling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class add_route extends AppCompatActivity implements View.OnClickListener{
    Button but_Add_Route;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_route);
        but_Add_Route = (Button) findViewById(R.id.but_Add_Route);

        but_Add_Route.setOnClickListener(this);
    }

    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.but_Add_Route:

               // startActivity(new Intent(this, Add_Route.class));


                break;
        }
    }
}