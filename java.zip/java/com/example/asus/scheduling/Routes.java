package com.example.asus.scheduling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Routes extends AppCompatActivity implements View.OnClickListener {
    Button but_Route1, but_Route2, but_Route3;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_routes);
        but_Route1 = (Button) findViewById(R.id.but_Route1);
        but_Route2 = (Button) findViewById(R.id.but_Route2);
        but_Route3 = (Button) findViewById(R.id.but_Route3);

        but_Route1.setOnClickListener(this);
        but_Route2.setOnClickListener(this);
        but_Route3.setOnClickListener(this);

    }

    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.but_Route1:

                startActivity(new Intent(this, Route1.class));


                break;

            case R.id.but_Route2:

                startActivity(new Intent(this, Route2.class));

                break;

            case R.id.but_Route3:

                startActivity(new Intent(this, Route3.class));

                break;

        }
    }
}
