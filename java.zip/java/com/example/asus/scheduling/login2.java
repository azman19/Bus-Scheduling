package com.example.asus.scheduling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login2 extends AppCompatActivity {
    private static EditText username;
    private static EditText password;
    private static Button but_LogIn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        Login2Button();
    }

    public void Login2Button() {

        username = (EditText)findViewById(R.id.etUserName);
        password = (EditText)findViewById(R.id.etPassword);
        but_LogIn2 = (Button)findViewById(R.id.but_SignIn);

        but_LogIn2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (username.getText().toString().equals("haridas")&&
                                password.getText().toString().equals("pritom") ) {
                            //Toast.makeText(,"UserName and PassWord is correct",
                                 //   Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent("com.example.asus.scheduling.add_route");
                            startActivity(intent);
                        }else {
                            Toast.makeText(login2.this,"UserName and PassWord is not correct",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
}}
