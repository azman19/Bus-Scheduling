package com.example.asus.scheduling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button but_LogIn, but_ContactUs, but_AboutUs , but_Routes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        but_LogIn = (Button)findViewById(R.id.but_LogIn);
        but_ContactUs = (Button)findViewById(R.id.but_ContactUs);
        but_AboutUs = (Button)findViewById(R.id.but_AboutUs);
        but_Routes =  (Button)findViewById(R.id.but_Routes);

        but_LogIn.setOnClickListener(this);
        but_ContactUs.setOnClickListener(this);
        but_AboutUs.setOnClickListener(this);
        but_Routes.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.but_LogIn:

                Intent intent = new Intent("com.example.asus.scheduling.login2");
                startActivity(intent);
                Toast.makeText(MainActivity.this,"LogIn here providing Username and Password",Toast.LENGTH_SHORT).show();

                break;

            case R.id.but_ContactUs:

                startActivity(new Intent(this, ContactUs.class));

                break;

            case R.id.but_AboutUs:

                startActivity(new Intent(this, AboutUs.class));

                break;

            case R.id.but_Routes:

                startActivity(new Intent(this, Routes.class));

                break;
        }

    }
}
