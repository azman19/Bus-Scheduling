package com.example.asus.scheduling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {
    private static EditText username;
    private static EditText password;
    private static Button but_LogIn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        LoginButton();
    }

     public void LoginButton() {

         username = (EditText)findViewById(R.id.etUserName);
         password = (EditText)findViewById(R.id.etPassword);
         but_LogIn = (Button)findViewById(R.id.but_LogIn);

         but_LogIn.setOnClickListener(
                 new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         if (username.getText().toString().equals("haridas")&&
                                 password.getText().toString().equals("pritom") ) {
                             Toast.makeText(LogIn.this,"UserName and PassWord is correct",
                                     Toast.LENGTH_SHORT).show();
                             Intent intent = new Intent("com.example.asus.scheduling.add_route");
                             startActivity(intent);
                         } else {
                             Toast.makeText(LogIn.this,"UserName and PassWord is not correct",
                                     Toast.LENGTH_SHORT).show();
                         }
                     }
                 }
         );

     }
}
